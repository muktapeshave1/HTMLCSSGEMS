var form = document.querySelector('form');

form.onsubmit = function(e) {
  e.preventDefault();
};
