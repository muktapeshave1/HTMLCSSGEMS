
var mainArr = [];

function table() {
    for (var i = 2; i <= 10; i++) {
        var arr = [];
        for (var j = 1; j <= 10; j++) {
            arr[j - 1] = i * j;
        }
        mainArr[i] = arr;
    }
}

postMessage(mainArr);

// var n = 10;
// var x = 2;
// var op = "";

// function tables(){
//     while(x<=n){
//         for(var i=1;i<=n;i++){
//             op+=(x*i)+",";
//         }
//         op+="<br/>";
//         x++;
//     }
//     console.log(op);
//     postMessage(op);
// }

// tables();